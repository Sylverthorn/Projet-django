from django.db import models






# Create your models here.

class Technique(models.Model):
    nom = models.CharField(max_length=100)
    description = models.TextField(max_length=500)
    type = models.ForeignKey("Type",
                            db_column="type_id",
                            on_delete = models.CASCADE,
                            max_length=100,
                            default=None,
                            related_name='techniques',
                    )

    

    def __str__(self):
        chaine = f"""{self.nom}"""
        return chaine

    def dico(self):
        return {"nom":self.nom, "description":self.description, "type":self.type}
    
    class Meta:
        ordering = ["nom"]

class Type(models.Model):
    
    type = models.CharField(max_length=100)
    
    def __str__(self):
        chaine = f"""{self.type}"""
        return chaine

    def dico(self):
        return {"type":self.type}
    
    

